// 设备列表
const devices = [
  { id: 1, name: '图书馆东侧', lat: 43.123, lng: 81.123, status: 1 },
  { id: 2, name: '食堂北侧',   lat: 43.124, lng: 81.124, status: 0 }
];
module.exports = (req, res) => res.status(200).json(devices);