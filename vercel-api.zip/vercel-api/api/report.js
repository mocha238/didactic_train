// 一键报修
module.exports = (req, res) => {
  console.log('报修设备:', req.body.id);
  res.status(200).json({ code: 0, msg: '已通知维修' });
};