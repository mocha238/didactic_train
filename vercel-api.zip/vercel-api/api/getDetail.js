// 30 天曲线
const devices = [{ id: 1, status: 1 }, { id: 2, status: 0 }];
module.exports = (req, res) => {
  const id   = Number(req.query.id);
  const fake = () => Array.from({ length: 30 }, () => (Math.random() * 0.4).toFixed(2));
  res.status(200).json({
    id,
    status: devices.find(d => d.id === id).status,
    time: Array.from({ length: 30 }, (_, i) => `12-${i + 1}`),
    pressure: fake(),
    temp: Array.from({ length: 30 }, () => (Math.random() * 30 + 5).toFixed(1))
  });
};