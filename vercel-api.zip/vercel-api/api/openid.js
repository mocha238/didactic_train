// openid 占位
module.exports = (req, res) => res.status(200).json({ openid: 'fake_openid' });